/*
 * Pixel Dungeon
 * Copyright (C) 2012-2015 Oleg Dolya
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>
 */
package com.watabou.pixeldungeon.scenes;


import com.badlogic.gdx.Gdx;
//import com.badlogic.gdx.Preferences;
import com.watabou.input.GameAction;
import com.watabou.noosa.BitmapText;
import com.watabou.noosa.Camera;
import com.watabou.noosa.Image;
import com.watabou.noosa.audio.Music;
import com.watabou.noosa.audio.Sample;
import com.watabou.noosa.ui.Button;
import com.watabou.pixeldungeon.Assets;
import com.watabou.pixeldungeon.PixelDungeon;
import com.watabou.pixeldungeon.effects.BannerSprites;
import com.watabou.pixeldungeon.effects.Fireball;
import com.watabou.pixeldungeon.ui.Archs;
import com.watabou.pixeldungeon.ui.ExitButton;
import com.watabou.pixeldungeon.ui.Icons;
import com.watabou.pixeldungeon.ui.PrefsButton;
import com.watabou.pixeldungeon.ui.SimpleButton;

public class TitleScene extends PixelScene
{
    private static final String TXT_PLAY = "Play";
    private static final String TXT_HIGHSCORES = "Rankings";
    private static final String TXT_BADGES = "Badges";
    private static final String TXT_ABOUT = "About";

//    BitmapText donateInfo;
//    SimpleButton btnDonate;

    @Override
    public void create()
    {
        super.create();

//        Gdx.app.log("Purchase", "檢查");

        Music.INSTANCE.play(Assets.THEME, true);
        Music.INSTANCE.volume(1f);

        uiCamera.visible = false;

        int w = Camera.main.width;
        int h = Camera.main.height;

        float height = 180;

        Archs archs = new Archs();
        archs.setSize(w, h);
        add(archs);

        Image title = BannerSprites.get(BannerSprites.Type.PIXEL_DUNGEON);
        add(title);

        title.x = (w - title.width()) / 2;
        title.y = (h - height) / 2;

        placeTorch(title.x + 18, title.y + 20);
        placeTorch(title.x + title.width - 18, title.y + 20);

        DashboardItem btnBadges = new DashboardItem(TXT_BADGES, 3)
        {
            @Override
            protected void onClick()
            {
                PixelDungeon.switchNoFade(BadgesScene.class);
            }
        };
        btnBadges.setPos(w / 2 - btnBadges.width(), (h + height) / 2 - DashboardItem.SIZE);
        add(btnBadges);

        DashboardItem btnAbout = new DashboardItem(TXT_ABOUT, 1)
        {
            @Override
            protected void onClick()
            {
                PixelDungeon.switchNoFade(AboutScene.class);
            }
        };
        btnAbout.setPos(w / 2, (h + height) / 2 - DashboardItem.SIZE);
        add(btnAbout);

        DashboardItem btnPlay = new DashboardItem(TXT_PLAY, 0)
        {
            @Override
            protected void onClick()
            {
                PixelDungeon.switchNoFade(StartScene.class);
            }
        };
        btnPlay.setPos(w / 2 - btnPlay.width(), btnAbout.top() - DashboardItem.SIZE);
        add(btnPlay);

        DashboardItem btnHighscores = new DashboardItem(TXT_HIGHSCORES, 2)
        {
            @Override
            protected void onClick()
            {
                PixelDungeon.switchNoFade(RankingsScene.class);
            }
        };
        btnHighscores.setPos(w / 2, btnPlay.top());
        add(btnHighscores);

        BitmapText version = createText(6);
        add(version);
        version.text("ver 1.0.9");
        version.measure();
        version.x = w - version.width() - 5;
        version.y = h - version.height();

        PrefsButton btnPrefs = new PrefsButton();
        btnPrefs.setPos(0, 0);
        add(btnPrefs);

        ExitButton btnExit = new ExitButton();
        btnExit.setPos(w - btnExit.width(), 0);
        add(btnExit);


        // check
//        Preferences prefs = Gdx.app.getPreferences("donate_state");
//        if (prefs.getBoolean("donate") == false)
//        {
//            if (PixelDungeon.iab == null)
//            {
////                BitmapText donateInfo = createText(6);
////                add(donateInfo);
////                donateInfo.text("不支持");
////                donateInfo.measure();
////                donateInfo.x = 6;
////                donateInfo.y = h - donateInfo.height();
//            }
//            else
//            {
//                BitmapText donateInfo = createText(6);
//                add(donateInfo);
//                donateInfo.text("贊助我們");
//                donateInfo.measure();
//                donateInfo.x = 6;
//                donateInfo.y = h - donateInfo.height();
//
//                // Donate
//                SimpleButton btnDonate = new SimpleButton(Icons.SUPPORT.get())
//                {
//                    protected void onClick()
//                    {
//                        PixelDungeon.iab.donate();
//                    }
//                };
//                btnDonate.setPos(10, donateInfo.y - btnDonate.height());
//                add(btnDonate);
//            }
//        }
//        else
//        {
//            BitmapText donateInfo = createText(6);
//            add(donateInfo);
//            donateInfo.text("偉大的贊助者!!");
//            donateInfo.color(255, 200, 0);
//            donateInfo.measure();
//            donateInfo.x = 6;
//            donateInfo.y = h - donateInfo.height();
//        }

        fadeIn();
    }


    private void placeTorch(float x, float y)
    {
        Fireball fb = new Fireball();
        fb.setPos(x, y);
        add(fb);
    }

    private static class DashboardItem extends Button<GameAction>
    {

        public static final float SIZE = 48;

        private static final int IMAGE_SIZE = 32;

        private Image image;
        private BitmapText label;

        public DashboardItem(String text, int index)
        {
            super();

            image.frame(image.texture.uvRect(index * IMAGE_SIZE, 0, (index + 1) * IMAGE_SIZE, IMAGE_SIZE));
            this.label.text(text);
            this.label.measure();

            setSize(SIZE, SIZE);
        }

        @Override
        protected void createChildren()
        {
            super.createChildren();

            image = new Image(Assets.DASHBOARD);
            add(image);

            label = createText(9);
            add(label);
        }

        @Override
        protected void layout()
        {
            super.layout();

            image.x = align(x + (width - image.width()) / 2);
            image.y = align(y);

            label.x = align(x + (width - label.width()) / 2);
            label.y = align(image.y + image.height() + 2);
        }

        @Override
        protected void onTouchDown()
        {
            image.brightness(1.5f);
            Sample.INSTANCE.play(Assets.SND_CLICK, 1, 1, 0.8f);
        }

        @Override
        protected void onTouchUp()
        {
            image.resetColor();
        }
    }
}
